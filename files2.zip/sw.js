const CACHE_NAME = 'invoice-keeper-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/auth.html',
  '/admin.html',
  '/user.html',
  '/style.css',
  '/script.js',
  '/logo.png',
  '/logo-light.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
});

self.addEventListener('fetch', (e) => {
  e.respondWith(
    caches.match(e.request).then((response) => response || fetch(e.request))
  );
});